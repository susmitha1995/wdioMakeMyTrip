
import Base from '../pageobjects/base.js'

import TestData from '../data/testdata.js'
import { User } from '../data/user.js';
import * as locators from '../pageobjects/locators.js';
import  Controls from '../pageobjects/actions.js';



before(async ()=>{
    await Base.open("makemytrip","flights")
         
})

let peoples: User[]; // Declare people here to have it available in the scope of the describe block
peoples = await TestData.readUserData(); // Await the Promise to get the actual data
describe("MakeMyTrip", () => {
    
    for (const people of peoples) {
        it(`valid login  for user ${people.triptype}, ${people.FareType}`, async () => {
            
            await Controls.click(locators.closeLoginWindow);
           let triptype = await locators.tripmode+"[data-cy="+`${people.triptype}`+"]"
           await Controls.isExisting(triptype, 10000, 3000)
           await Controls.click(triptype)
           await Controls.isExisting(locators.submit, 10000, 3000)
           await Controls.isDisplayed(locators.submit)
           await Controls.click(locators.submit)
           let fareType = await locators.fareType+"[text()='"+`${people.FareType}`+"']";
           await Controls.isExisting(fareType, 10000, 3000)          
           await Controls.click(fareType)
           await Controls.isDisplayed(locators.priceList)
          

           const priceListTexts = await Controls.getTexts(locators.priceList);

        // Convert the text values to numbers if needed
          const numericPriceList = priceListTexts.map(text => parseFloat(text));

        // Sort the numericPriceList array in ascending order
        numericPriceList.sort((a, b) => a - b);
        
        // Print the first three prices
        const firstThreePrices = numericPriceList.slice(0, 3);
        console.log(firstThreePrices);
        
        
        })
    }
})

after(async () => {
    await browser.saveScreenshot(__dirname + ".png");
});