import propertiesReader from 'properties-reader';

// Load the properties file
const properties = propertiesReader('D:/Js/wdio-testdata-ts-main/test/pageelements/TheInternetPageElements.properties');

// Get the value of the 'username' property and assert its type
const userName = properties.get('username') as string;
const password = properties.get('password') as string;
const submit = properties.get('submit') as string;
const flash = properties.get('flash') as string;
const tripmode = properties.get('tripmode') as string;
const fareType = properties.get('fareType') as string;
const priceList = properties.get('priceList') as string;
const closeLoginWindow = properties.get('closeLoginWindow') as string;

closeLoginWindow


export { userName, password, submit, flash, tripmode, fareType, priceList, closeLoginWindow};