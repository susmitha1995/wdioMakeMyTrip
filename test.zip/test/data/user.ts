// username	password	expected

export type User = {
  triptype: string;
  FareType: string;
 // expected: string;
};